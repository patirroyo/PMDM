import { Component, OnInit } from '@angular/core';
import { CursosService } from './cursoService';
import { Curso } from './curso';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AlumnosComponent } from '../alumnos/alumnos.component';

@Component({
  selector: 'app-curso',
  standalone: true,
  imports: [CommonModule, AlumnosComponent],
  providers: [CursosService, RouterModule],
  templateUrl: './curso.component.html',
  styleUrl: './curso.component.css'
})
export class CursoComponent implements OnInit {

  cursos: Curso[] = [];
  seleccionado: number = 0;

  constructor(public losCursos: CursosService) { }

  ngOnInit(): void {
    this.losCursos.getCursos().subscribe(
      (result) => {
        this.cursos = result;
      },
      (error) => {
        console.log(error);
      }
    );

  }
  onChange(c: string) {
    this.seleccionado = Number(c);
  }


}
