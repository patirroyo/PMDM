import { Routes } from '@angular/router';
import { Curso } from './curso/curso';

export const routes: Routes = [
    { path: 'Cursos', component: Curso },
];
